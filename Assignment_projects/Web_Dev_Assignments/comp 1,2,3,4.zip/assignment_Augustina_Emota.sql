/*
Name:
Date:
Assignments:
*/

--1. This is a single line comment
SELECT*
FROM Employees;