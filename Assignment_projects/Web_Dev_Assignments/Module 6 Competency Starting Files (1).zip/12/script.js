/********w*************

    Do not alter this comment block. 
    Only fill out the information below.
    
    Competency 12 Javascript Syntax
    Name: 
    Date:
    Description:

**********************/

