/********w*************

    Do not alter this comment block. 
    Only fill out the information below.

    Competency 14 
    Name: 
    Date:
    Description:

**********************/

document.addEventListener("DOMContentLoaded", load);

/*	
    Load function
    Create, insert, and delete elements
*/
function load() {

}




