import unittest
from unittest import TestCase
from input_handler.input_handler import InputHandler

class InputHandlerTests(TestCase):
    









if __name__ == "__main__":
    unittest.main()